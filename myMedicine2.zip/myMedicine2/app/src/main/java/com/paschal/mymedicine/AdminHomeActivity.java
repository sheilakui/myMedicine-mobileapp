package com.paschal.mymedicine;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class AdminHomeActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_home);
    }
}