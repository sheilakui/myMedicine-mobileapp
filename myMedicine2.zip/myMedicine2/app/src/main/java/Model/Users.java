package Model;

public class Users {
    private String name, phone_number, password;

    public Users(){

    }

    public Users(String name, String phone_number, String password) {
        this.name = name;
        this.phone_number = phone_number;
        this.password = password;

    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPhone_number() {
        return phone_number;
    }

    public void setPhone_number(String phone_number) {
        this.phone_number = phone_number;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
}
