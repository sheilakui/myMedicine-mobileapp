package Prevalent;

import Model.Users;

public class Prevalent {
    private static Users currentOnlineUser;

}
